﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;

public class schat : Ischat
{
    public async Task MandaMsg(string msg, int idusuario)
    {
        ;
    }

    public async Task MsgNuevo(string msg, int idusuario)
    {
        ;
    }
}
